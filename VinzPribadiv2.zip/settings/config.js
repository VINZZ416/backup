
/*─────────────────────────────────────────
  GitHub   : https://github.com/kiuur    
  YouTube  : https://youtube.com/@kyuurzy
  Rest API : https://laurine.site        
  Telegram : https://kyuucode.t.me       
──────────────────────────────────────────*/

const fs = require('fs')

global.owner = "6289521456041"
global.linkch = "https://whatsapp.com/channel/0029VbAlqqWGU3BL27WTTQ3G"

global.status = true
global.welcome = true

global.mess = {
    owner: "*NGAPAIN DEK,KHUSUS BANG VINZTAMVAN INI*",
    group: "DONGONYA KEBANGETAN,FITUR KHUSUS GRUP TOLOL",
    private: "DONGONYA KEBANGETAN,FITUR KHUSUS PRIVAT CHAT TOLOL"
}

global.packname = 'Dr.VinzClound'
global.author = 'https://t.me/Veceptive'
global.pairing = "PELERRRR"

global.KEY = "GET APIKEY elevenlabs.io"
global.IDVOICE = "GET ON elevenlabs.io"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})